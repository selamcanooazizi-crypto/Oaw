package tr.boomac;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.lang.reflect.Method;
import java.util.*;

public class BoomAC extends JavaPlugin implements Listener {

    static class Data {
        Map<String, Integer> counts = new HashMap<>();
        Map<String, Double> buf = new HashMap<>();
        int total = 0;
        boolean punished = false;
        BukkitTask task;
        long lastVelocity, lastTeleport, lastAttack, lastFirework, lastHit;
        Entity lastTarget;
        UUID lastHitId;
        ArrayDeque<Long> hits = new ArrayDeque<>();
        List<double[]> aim = new ArrayList<>();
    }

    private final Map<UUID, Data> map = new HashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        long decay = Math.max(10, getConfig().getInt("decay-seconds", 90)) * 20L;
        getServer().getScheduler().runTaskTimer(this, () -> {
            for (Data d : map.values()) {
                if (d.punished) continue;
                if (d.total > 0) d.total--;
                for (String k : new ArrayList<>(d.counts.keySet())) {
                    int v = d.counts.get(k) - 1;
                    if (v <= 0) d.counts.remove(k); else d.counts.put(k, v);
                }
            }
        }, decay, decay);
    }

    private Data d(Player p) {
        Data x = map.get(p.getUniqueId());
        if (x == null) { x = new Data(); map.put(p.getUniqueId(), x); }
        return x;
    }

    private boolean exempt(Player p, Data d) {
        String gm = p.getGameMode().name();
        return d.punished || p.hasPermission("ac.bypass") || gm.equals("CREATIVE") || gm.equals("SPECTATOR");
    }

    private boolean bad(Data d, String key, boolean cond, double need) {
        double v = d.buf.containsKey(key) ? d.buf.get(key) : 0;
        v = cond ? v + 1 : Math.max(0, v - 0.25);
        if (v >= need) { d.buf.put(key, 0.0); return true; }
        d.buf.put(key, v);
        return false;
    }

    // ---------- reflection helpers (1.8 - en yeni sürüm uyumu) ----------
    private static boolean gliding(Player p) {
        try { return (Boolean) Player.class.getMethod("isGliding").invoke(p); } catch (Throwable t) { return false; }
    }

    private static ItemStack hand(Player p) {
        try {
            Method m = p.getInventory().getClass().getMethod("getItemInMainHand");
            return (ItemStack) m.invoke(p.getInventory());
        } catch (Throwable t) {
            try { return (ItemStack) p.getInventory().getClass().getMethod("getItemInHand").invoke(p.getInventory()); }
            catch (Throwable t2) { return null; }
        }
    }

    private static String mat(ItemStack i) { return i == null ? "AIR" : i.getType().name(); }

    private static void title(Player p, String t, String s) {
        try {
            Player.class.getMethod("sendTitle", String.class, String.class, int.class, int.class, int.class)
                    .invoke(p, t, s, 0, 40, 10);
            return;
        } catch (Throwable ignored) { }
        try { Player.class.getMethod("sendTitle", String.class, String.class).invoke(p, t, s); return; }
        catch (Throwable ignored) { }
        p.sendMessage(t + " " + s);
    }

    // ---------- flag / alert ----------
    private void flag(Player p, Data d, String type) {
        if (d.punished) return;
        int w = getConfig().getInt("weights." + type, 1);
        int n = d.counts.containsKey(type) ? d.counts.get(type) + 1 : 1;
        d.counts.put(type, n);
        d.total += w;
        int th = getConfig().getInt("threshold", 5);
        String msg = "§c[AC] §f" + p.getName() + " §7→ §e" + n + "x §c" + type
                + " §8(toplam " + d.total + "/" + th + ")";
        for (Player s : Bukkit.getOnlinePlayers())
            if (s.hasPermission("ac.alerts") && !alertsOff.contains(s.getUniqueId())) s.sendMessage(msg);
        Bukkit.getConsoleSender().sendMessage(msg);
        if (d.total >= th) punish(p, d);
    }

    private void ban(String name) {
        int days = getConfig().getInt("ban-days", 14);
        Date until = new Date(System.currentTimeMillis() + days * 86400000L);
        Bukkit.getBanList(BanList.Type.NAME).addBan(name, "§cHile kullandığın için " + days + " gün banlandın.", until, "BoomAC");
    }

    private void punish(final Player p, final Data d) {
        d.punished = true;
        final int ticks = getConfig().getInt("flight-seconds", 5) * 20;
        Bukkit.broadcast("§c[AC] §f" + p.getName() + " §chile yüzünden havaya uçuruluyor!", "ac.alerts");
        try { p.setAllowFlight(true); } catch (Throwable ignored) { }
        title(p, "§c§lBOOM!", "§fYakalandın!");
        d.task = new org.bukkit.scheduler.BukkitRunnable() {
            int t = 0;
            public void run() {
                if (!p.isOnline()) { cancel(); return; }
                if (t < ticks) {
                    p.setFallDistance(0f);
                    p.setVelocity(new Vector(0, 0.6, 0));
                    if (t % 20 == 0) title(p, "§c§lBOOM!", "§fYakalandın!");
                } else if (t == ticks) {
                    title(p, "§6§lBay bay hileci", "§7Görüşürüz...");
                } else if (t >= ticks + 30) {
                    Location l = p.getLocation();
                    l.getWorld().createExplosion(l.getX(), l.getY(), l.getZ(), 0f);
                    ban(p.getName());
                    p.kickPlayer("§cHile kullandığın için " + getConfig().getInt("ban-days", 14) + " gün banlandın.");
                    cancel();
                }
                t++;
            }
        }.runTaskTimer(this, 1L, 1L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Data d = map.get(e.getPlayer().getUniqueId());
        if (d != null && d.punished) {
            if (d.task != null) d.task.cancel();
            ban(e.getPlayer().getName());   // cezadayken çıkarsa yine 14 gün
        }
    }

    // ---------- bağlantı olayları (false-positive önleme) ----------
    @EventHandler
    public void onVel(PlayerVelocityEvent e) { d(e.getPlayer()).lastVelocity = System.currentTimeMillis(); }

    @EventHandler
    public void onTp(PlayerTeleportEvent e) { d(e.getPlayer()).lastTeleport = System.currentTimeMillis(); }

    // ---------- SPEED + TARGET STRAFE ----------
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        Data d = d(p);
        if (exempt(p, d)) return;
        Location f = e.getFrom(), t = e.getTo();
        if (t == null || f.getWorld() != t.getWorld()) return;
        double dx = t.getX() - f.getX(), dz = t.getZ() - f.getZ();
        double h = Math.sqrt(dx * dx + dz * dz);
        if (h == 0) return;
        long now = System.currentTimeMillis();
        if (p.isFlying() || p.getAllowFlight() || p.isInsideVehicle() || gliding(p)
                || now - d.lastVelocity < 1500 || now - d.lastTeleport < 1500) return;

        int lvl = 0;
        for (org.bukkit.potion.PotionEffect pe : p.getActivePotionEffects())
            if (pe.getType().getName().equals("SPEED")) lvl = pe.getAmplifier() + 1;
        boolean ice = t.clone().subtract(0, 1, 0).getBlock().getType().name().contains("ICE");

        double limit = 0.70 + 0.12 * lvl + (ice ? 0.4 : 0);
        if (bad(d, "speed", h > limit, 3)) { flag(p, d, "SPEED"); return; }

        // Target strafe: birine vururken etrafında çok hızlı dönmek
        if (d.lastTarget != null && now - d.lastAttack < 700 && d.lastTarget.getWorld() == t.getWorld()) {
            double dist = d.lastTarget.getLocation().distance(t);
            double tx = d.lastTarget.getLocation().getX() - f.getX();
            double tz = d.lastTarget.getLocation().getZ() - f.getZ();
            double tl = Math.sqrt(tx * tx + tz * tz);
            double cos = tl == 0 ? 1 : Math.abs((dx * tx + dz * tz) / (h * tl));
            boolean strafe = dist < 5 && h > 0.55 + 0.10 * lvl && cos < 0.6;
            if (bad(d, "strafe", strafe, 4)) flag(p, d, "TARGET_STRAFE");
        }
    }

    // ---------- KILL AURA + AIM ASSIST + ELYTRA TARGET ----------
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player) || !(e.getEntity() instanceof LivingEntity)) return;
        if (!e.getCause().name().equals("ENTITY_ATTACK")) return;
        Player p = (Player) e.getDamager();
        Data d = d(p);
        if (exempt(p, d)) return;
        Entity v = e.getEntity();
        long now = System.currentTimeMillis();

        Location eye = p.getEyeLocation();
        Location center = v.getLocation().add(0, 0.9, 0);
        double dist = eye.distance(center);

        // Reach
        if (dist > 6.2) { flag(p, d, "KILL_AURA"); }

        // Bakmadan vurma (açı)
        Vector to = center.toVector().subtract(eye.toVector());
        double angle = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, to.normalize().dot(eye.getDirection())))));
        if (bad(d, "angle", angle > 95 && dist > 2.0, 3)) flag(p, d, "KILL_AURA");

        // Çoklu hedef (çok kısa sürede farklı hedefler)
        UUID id = v.getUniqueId();
        boolean multi = d.lastHitId != null && !d.lastHitId.equals(id) && now - d.lastHit < 60;
        if (bad(d, "multi", multi, 2)) flag(p, d, "KILL_AURA");
        d.lastHitId = id; d.lastHit = now;

        // CPS
        d.hits.addLast(now);
        while (!d.hits.isEmpty() && now - d.hits.peekFirst() > 1000) d.hits.pollFirst();
        if (bad(d, "cps", d.hits.size() > 22, 2)) flag(p, d, "KILL_AURA");

        // Aim assist: nişan hep aynı noktada sabit mi?
        double yawTo = Math.toDegrees(Math.atan2(-to.getX(), to.getZ()));
        double yawErr = wrap(eye.getYaw() - yawTo);
        double hz = Math.sqrt(to.getX() * to.getX() + to.getZ() * to.getZ());
        double pitchTo = -Math.toDegrees(Math.atan2(to.getY(), hz));
        double pitchErr = eye.getPitch() - pitchTo;
        if (now - d.lastAttack > 15000) d.aim.clear();
        d.aim.add(new double[]{yawErr, pitchErr, v.getVelocity().length() > 0.05 || d.lastTarget != v ? 1 : 0});
        if (d.aim.size() > 8) d.aim.remove(0);
        if (d.aim.size() == 8) {
            if (std(d.aim, 0) < 0.35 && std(d.aim, 1) < 0.35) {
                d.aim.clear();
                flag(p, d, "AIM_ASSIST");
            }
        }

        // Elytra target
        if (gliding(p)) {
            String m = mat(hand(p));
            boolean holdFw = m.contains("FIREWORK");
            boolean swordDmg = e.getDamage() >= 4.0;
            if ((holdFw && swordDmg) || (swordDmg && now - d.lastFirework < 400)) flag(p, d, "ELYTRA_TARGET");
        }

        d.lastAttack = now;
        d.lastTarget = v;
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        Data d = d(p);
        ItemStack it = e.getItem();
        if (it == null || !it.getType().name().contains("FIREWORK")) return;
        long now = System.currentTimeMillis();
        d.lastFirework = now;
        if (exempt(p, d) || !gliding(p)) return;
        // Elinde kılıç/balta varken (diğer elle) fişek basıp saldırı yapmak
        String main = mat(hand(p));
        boolean weapon = main.endsWith("SWORD") || main.endsWith("_AXE");
        boolean off = false;
        try { off = String.valueOf(e.getClass().getMethod("getHand").invoke(e)).equals("OFF_HAND"); } catch (Throwable ignored) { }
        if (weapon && off && now - d.lastAttack < 1500) flag(p, d, "ELYTRA_TARGET");
    }

    private static double wrap(double a) {
        a %= 360; if (a > 180) a -= 360; if (a < -180) a += 360; return a;
    }

    private static double std(List<double[]> l, int i) {
        double m = 0; for (double[] x : l) m += x[i]; m /= l.size();
        double s = 0; for (double[] x : l) s += (x[i] - m) * (x[i] - m);
        return Math.sqrt(s / l.size());
    }

    // ---------- komutlar ----------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) { s.sendMessage("§e/ac alerts §7- bildirimleri aç/kapat\n§e/ac reset <oyuncu>\n§e/ac reload"); return true; }
        if (a[0].equalsIgnoreCase("alerts") && s instanceof Player) {
            UUID u = ((Player) s).getUniqueId();
            if (alertsOff.remove(u)) s.sendMessage("§a[AC] Bildirimler açık.");
            else { alertsOff.add(u); s.sendMessage("§c[AC] Bildirimler kapalı."); }
        } else if (a[0].equalsIgnoreCase("reset") && a.length > 1 && s.hasPermission("ac.admin")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t != null) { map.remove(t.getUniqueId()); s.sendMessage("§a[AC] Loglar sıfırlandı."); }
        } else if (a[0].equalsIgnoreCase("reload") && s.hasPermission("ac.admin")) {
            reloadConfig(); s.sendMessage("§a[AC] Config yenilendi.");
        }
        return true;
    }
}
